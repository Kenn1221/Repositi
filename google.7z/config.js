const fs = require('fs')
const chalk = require('chalk')

// ganti info bot dibawah ini
global.botName = "FluXz-BoTz Bug"
global.ownerName = "FluXz"
global.ownerBot = "6282172794332"
global.ownerNumber = ["6282172794332"] 

global.Auto_Typing = false // auto typing
global.Auto_Recording = false // auto recording
global.Auto_ReadPesan = true // auto read messages

// Auto Downloader Tiktok
global.TiktokAutoDownload = true

// Admin Create Panel
global.domain = "https://panelbot.sellerpanel.biz.id" // Ganti Domain Lu
global.key_plta = "ptla_0cbkvwgbNDUlNqXaPRyDqFqmzmzOuJ8TzjXLiK2Xggk" // Isi Apikey Plta Lu
global.key_pltc = "ptlc_9BEb2abXAIg5LJtzrf0vENywKD0w5k34yH0pUZtXtW0" // Isi Apikey Pltc Lu
global.nama_host = "FluXzHost45" // Ganti Nama Store Atau nama Host Lu
global.locID = '1'
global.eggID = '15'

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})